import japa.parser.ast.body.ConstructorDeclaration;
import japa.parser.ast.body.Parameter;
import japa.parser.ast.type.Type;

import java.util.ArrayList;
import java.util.List;

public class ConstructorVisitor extends japa.parser.ast.visitor.VoidVisitorAdapter<Void>
{
  ArrayList<String> constructors = new ArrayList<String>();
  ArrayList<String> constructorDependency = new ArrayList<String>();
  ArrayList<String> classNames = new ArrayList<String>();
  String javaclassName = null;
  
  public ConstructorVisitor(ArrayList<String> classNames, String javaclassName)
  {
    this.classNames = classNames;
    this.javaclassName = javaclassName;
  }
  




  public ArrayList<String> getConstructorDependency()
  {
    return constructorDependency;
  }
  
  public ArrayList<String> getConstructors() {
    return constructors;
  }
  
  public void visit(ConstructorDeclaration n, Void arg)
  {
    StringBuffer sb = new StringBuffer();
    String method = null;
    String dependent = null;
    if ((n.getParameters() != null) && ((n.getModifiers() == 1) || (n.getModifiers() == 1025))) {
      for (int i = 0; i < n.getParameters().size(); i++) {
        if (classNames.contains(((Parameter)n.getParameters().get(i)).getType().toString())) {
          dependent = javaclassName + " ..> " + ((Parameter)n.getParameters().get(i)).getType().toString();
          
          if (!constructorDependency.contains(dependent))
            constructorDependency.add(dependent);
        }
        sb.append(((Parameter)n.getParameters().get(i)).getId() + " : " + ((Parameter)n.getParameters().get(i)).getType());
        if ((n.getParameters().size() > 1) && (i != n.getParameters().size() - 1))
          sb.append(" ");
      }
      method = "+ " + n.getName() + "(" + sb.toString() + ")";
    } else if ((n.getModifiers() == 1) || (n.getModifiers() == 1025)) {
      method = "+ " + n.getName() + "()";
    }
    if (method != null) {
      constructors.add(method);
    }
  }
}