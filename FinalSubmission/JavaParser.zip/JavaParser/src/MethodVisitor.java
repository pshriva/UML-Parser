import japa.parser.ast.body.MethodDeclaration;
import japa.parser.ast.body.Parameter;

import java.util.ArrayList;
import java.util.List;

public class MethodVisitor extends japa.parser.ast.visitor.VoidVisitorAdapter<Void>
{
  ArrayList<String> classNames = new ArrayList<String>();
  ArrayList<String> fieldNames = new ArrayList<String>();
  ArrayList<String> dependency = new ArrayList<String>();
  ArrayList<String> methodNames = new ArrayList<String>();
  String javaclassName = null;
  
  public ArrayList<String> getDependency() { return dependency; }
  
  public ArrayList<String> getMethodNames() {
    return methodNames;
  }
  
  public MethodVisitor(ArrayList<String> classNames, String javaclassName, ArrayList<String> fieldNames) {
    this.classNames = classNames;
    this.javaclassName = javaclassName;
    this.fieldNames = fieldNames;
  }
  

  public void visit(MethodDeclaration m, Void arg)
  {
    String method = null;
    StringBuffer sb = new StringBuffer();
    String dependent = null;
    

    String field = null;
    field = getGetterSetterStatus(m);
    if (field != null) {
      String[] fieldTokens = field.split(" ");
      fieldNames.remove(field);
      fieldNames.add("+ " + fieldTokens[1] + " " + fieldTokens[2] + " " + fieldTokens[3]);
    }
    
    if ((m.getParameters() != null) && ((m.getModifiers() == 1) || (m.getModifiers() == 1025) || (m.getModifiers() == 9))) {
      for (int i = 0; i < m.getParameters().size(); i++) {
        if (classNames.contains(((Parameter)m.getParameters().get(i)).getType().toString())) {
          dependent = javaclassName + " ..> " + ((Parameter)m.getParameters().get(i)).getType().toString();
          if (!dependency.contains(dependent))
            dependency.add(dependent);
        }
        sb.append(((Parameter)m.getParameters().get(i)).getId() + " : " + ((Parameter)m.getParameters().get(i)).getType());
        if ((m.getParameters().size() > 1) && (i != m.getParameters().size() - 1))
          sb.append(" ");
      }
      if (m.getModifiers() == 9) {
        method = "+ " + m.getName() + "(" + sb.toString() + ") : " + m.getType() + "{static}";
      } else {
        method = "+ " + m.getName() + "(" + sb.toString() + ") : " + m.getType();
      }
    } else if ((m.getModifiers() == 1) || (m.getModifiers() == 1025)) {
      method = "+ " + m.getName() + "() : " + m.getType();
    } else if (m.getModifiers() == 9) {
      method = "+ " + m.getName() + "(" + sb.toString() + ") : " + m.getType() + "{static}";
    }
    if ((method != null) && (field == null)) {
      methodNames.add(method);
    }
    if ((m.getBody() != null) && 
      (m.getBody().getStmts() != null)) {
      for (int i = 0; i < m.getBody().getStmts().size(); i++) {
        String statement = ((japa.parser.ast.stmt.Statement)m.getBody().getStmts().get(i)).toString();
        if ((statement.contains(" = new")) || (statement.contains(" =new"))) {
          String[] reference = statement.split("=");
          for (String classname : classNames) {
            if ((reference[0].toString().contains(classname)) && (!dependency.contains(javaclassName + " ..> " + classname))) {
              dependency.add(javaclassName + " ..> " + classname);
            }
          }
        }
      }
    }
  }
  

  private String getGetterSetterStatus(MethodDeclaration m)
  {
    String field = null;
    for (String fieldname : fieldNames) {
      String[] attribute = fieldname.split(" ");
      if ((m.getName().equalsIgnoreCase("get" + attribute[1])) || (m.getName().equalsIgnoreCase("set" + attribute[1]))) {
        field = fieldname;
      }
    }
    return field;
  }
}