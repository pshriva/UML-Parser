import japa.parser.JavaParser;
import japa.parser.ast.CompilationUnit;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;

public class MyUMLParser
{
  static String inputfilepath;
  static String outputfilepath;
  static String[] javaClassName;
  static File parseFile;
  static ArrayList<String> classNames = new ArrayList<String>();
  static ArrayList<String> implementedClasses = new ArrayList<String>();
  static ArrayList<String> totalImplementedClasses = new ArrayList<String>();
  static ArrayList<String> methodNames = new ArrayList<String>();
  static ArrayList<String> fieldNames = new ArrayList<String>();
  static ArrayList<String> subClassNames = new ArrayList<String>();
  static ArrayList<String> totalSubClassNames = new ArrayList<String>();
  static ArrayList<String> associations = new ArrayList<String>();
  static ArrayList<String> totalAssociations = new ArrayList<String>();
  static ArrayList<String> dependency = new ArrayList<String>();
  static ArrayList<String> totalDependency = new ArrayList<String>();
  static ArrayList<String> constructorDependency = new ArrayList<String>();
  static ArrayList<String> totalConstructorDependency = new ArrayList<String>();
  static ArrayList<String> interfaces = new ArrayList<String>();
  static ArrayList<String> totalInterfaces = new ArrayList<String>();
  static ArrayList<String> constructors = new ArrayList<String>();
  static StringBuffer umlFile = new StringBuffer();
  static CompilationUnit cu;
  static ConstructorVisitor constructorVisitor;
  
  public MyUMLParser() {}
  
  public static void main(String[] args) throws IOException
  {
    inputfilepath = args[0];
    outputfilepath = args[1];
    
    File file = new File(inputfilepath);
    UMLGenerator umlgenerator = new UMLGenerator();
    classNames = getJavaClasses(file);
    parseFiles(file);
    umlgenerator.createClassDiagram(umlFile.toString(), outputfilepath);
  }
  
  private static ArrayList<String> getJavaClasses(File file) { ArrayList<String> classes = new ArrayList<String>();
    
    File[] files = file.listFiles();
    for (File f : files) {
      if (f.getName().contains(".java")) {
        javaClassName = f.getName().split("\\.");
        classes.add(javaClassName[0]);
      }
    }
    
    return classes; }
  
  static MethodVisitor methodVisitor;
  private static void parseFiles(File file) { File[] files = file.listFiles();
    umlFile.append("@startuml\n");
    for (File f : files) {
      if (f.getName().contains(".java")) {
        javaClassName = f.getName().split("\\.");
        try
        {
          cu = JavaParser.parse(f);
          JavaParser.setCacheParser(false);
        }
        catch (Exception e) {
          e.printStackTrace();
        }
        fieldVisitor = new FieldVisitor(classNames, javaClassName[0]);
        fieldVisitor.visit(cu, null);
        fieldNames = fieldVisitor.getFieldNames();
        associations = fieldVisitor.getAssociations();
        methodVisitor = new MethodVisitor(classNames, javaClassName[0], fieldNames);
        methodVisitor.visit(cu, null);
        methodNames = methodVisitor.getMethodNames();
        dependency = methodVisitor.getDependency();
        for (String s : dependency) {
          if (!totalDependency.contains(s))
            totalDependency.add(s);
        }
        constructorVisitor = new ConstructorVisitor(classNames, javaClassName[0]);
        constructorVisitor.visit(cu, null);
        constructors = constructorVisitor.getConstructors();
        constructorDependency = constructorVisitor.getConstructorDependency();
        for (String s : constructorDependency) {
          if (!totalConstructorDependency.contains(s))
            totalConstructorDependency.add(s);
        }
        interfaceAndClassVisitor = new InterfaceAndClassVisitor(javaClassName[0]);
        interfaceAndClassVisitor.visit(cu, null);
        interfaces = interfaceAndClassVisitor.getInterfaces();
        for (String s : interfaces) {
          if (!totalInterfaces.contains(s))
            totalInterfaces.add(s);
        }
        subClassNames = interfaceAndClassVisitor.getSubClassNames();
        for (String s : subClassNames) {
          if (!totalSubClassNames.contains(s))
            totalSubClassNames.add(s);
        }
        implementedClasses = interfaceAndClassVisitor.getImplementedClasses();
        for (String s : implementedClasses) {
          if (!totalImplementedClasses.contains(s)) {
            totalImplementedClasses.add(s);
          }
        }
        
        createFile();
      }
    }
    
    getConnections(); }
  
  static InterfaceAndClassVisitor interfaceAndClassVisitor;
  static FieldVisitor fieldVisitor;
  public static void createFile() { if (cu.getTypes().toString().contains("interface")) {
      umlFile.append("Interface " + javaClassName[0] + "{\n");
    }
    else {
      umlFile.append("Class " + javaClassName[0] + "{\n");
    }
    
    for (String fName : fieldNames) {
      umlFile.append(fName + "\n");
    }
    umlFile.append("\n");
    for (String fName : constructors) {
      umlFile.append(fName + "\n");
    }
    umlFile.append("\n");
    for (String mname : methodNames) {
      umlFile.append(mname + "\n");
    }
    umlFile.append("}\n");
    methodNames.clear();
    fieldNames.clear();
    constructors.clear();
  }
  
  public static void getConnections() { for (String iName : totalImplementedClasses) {
      umlFile.append(iName + "\n");
    }
    for (String cName : totalSubClassNames) {
      umlFile.append(cName + "\n");
    }
    for (String asName : associations) {
      umlFile.append(asName + "\n");
    }
    for (String asName : totalDependency) {
      String[] ifaces = asName.split(" ");
      if ((!totalInterfaces.contains(ifaces[0])) && (totalInterfaces.contains(ifaces[2])))
      {
        umlFile.append(asName + "\n");
      }
    }
    
    for (String asName1 : totalConstructorDependency) {
      String[] ifaces = asName1.split(" ");
      if ((!totalInterfaces.contains(ifaces[0])) && (totalInterfaces.contains(ifaces[2])))
      {
        umlFile.append(asName1 + "\n");
      }
    }
    
    umlFile.append("@enduml");
  }
}