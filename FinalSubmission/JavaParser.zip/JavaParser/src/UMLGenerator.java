import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import net.sourceforge.plantuml.FileFormat;
import net.sourceforge.plantuml.FileFormatOption;
import net.sourceforge.plantuml.SourceStringReader;


public class UMLGenerator
{
  public UMLGenerator() {}
  
  public void createClassDiagram(String umlFile, String outputfilepath)
    throws IOException
  {
    SourceStringReader reader = new SourceStringReader(umlFile);
    
    FileOutputStream output = new FileOutputStream(new File(outputfilepath));
    reader.generateImage(output, new FileFormatOption(FileFormat.SVG, false));
  }
}